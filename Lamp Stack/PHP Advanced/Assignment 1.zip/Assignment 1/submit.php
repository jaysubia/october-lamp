<?php

var_dump($_POST);

echo '<h1>Submitted Information</h1>';

echo '<p>Name: ' . $_POST['name'] . '</p>';

echo '<p>Dojo Location: ' . $_POST['location'] . '</p>';

echo '<p>Favorite Language: ' . $_POST['language'] . '</p>';

echo '<p>Comment: ' . $_POST['comment'] . '</p>';

?>


